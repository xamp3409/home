<!DOCTYPE html>
<html>
  <head>
    <title>Public Home</title>
  </head>
  <body>
    <table border="1" cellspacing="0" width="80%" >
      <tr>
         <td>
          <table width="100%">
              <tr>
                <td><img height="40px" weight="40px" src="../Resources/school_logo.png" alt=""></td>
                <td align = "right">
                    <a href="HomePage.php">Home</a>|
                    <a href="LoginPage.php">Login</a>|
                    <a href="Registration.php">Registration</a>
                </td>
              </tr>
          </table>
          </td>
      </tr>
      <tr>
        <td align="center" height="150px" weight="150px" colspan="2"><h1>School Management System</h1></td>
      </tr>
      <?php include("TeacherFooter.php") ?>
    </table>

  </body>
</html>