<tr>
         <td colspan="2">
          <table width="100%">
              <tr>
                <td><img height="40px" weight="40px" src="../Resources/school_logo.png" alt=""></td>
                <td align = "right">
                    <a href="../Controller/Logout.php">Logout</a>
                </td>
              </tr>
          </table>
          </td>
      </tr>