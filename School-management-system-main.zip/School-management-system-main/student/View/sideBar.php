<tr>
        <td width="250px">
          <h3>My Account</h3>
          <hr>
          <ul>
            <li><a href="dashboard.php">Dashboard</a></li>  
            <li><a href="routine.php">Class Routine</a></li>
            <li><a href="viewprofile.php">View Profile</a></li>
            <li><a href="teachernotice.php">Teachers Notice</a></li>
            <li><a href="teacherprofile.php">Teachers Contact Details</a></li>
            <li><a href="schoolnotice.php">School Notices</a></li>
            <li><a href="result.php">Own Result</a></li>
            <li><a href="reset.php">Change Password</a></li>
            <li><a href="leaverequest.php">Request for leave</a></li>
            <li><a href="coursedetails.php">Course Details</a></li>
            <li><a href="upload.php">Upload Document</a></li>
            <li><a href="requestforbook.php">Request of Books</a></li>
            <li><a href="issuebook.php">Issue Book History</a></li>
            <li><a href="booksinfo.php">Information of Books</a></li>

          </ul>
        </td>