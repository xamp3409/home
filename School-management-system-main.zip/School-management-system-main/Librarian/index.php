<?php

	header('location: View/librarianLogin.php');

?>